#ifndef __PPC_ARCH_H__
# define __PPC_ARCH_H__

extern unsigned int OPENSSL_ppccap_P;

# define PPC_FPU64       (1<<0)
# define PPC_ALTIVEC     (1<<1)
# define PPC_CRYPTO207   (1<<2)

#endif
